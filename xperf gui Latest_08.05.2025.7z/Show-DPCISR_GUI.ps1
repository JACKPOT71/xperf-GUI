param(
    [string]$JsonFile
)

# Debug output
Write-Host "Loading JSON file: $JsonFile"

if (-not (Test-Path $JsonFile)) {
    [System.Windows.Forms.MessageBox]::Show("Result file not found!`n$JsonFile", "Error", "OK", "Error")
    exit 1
}

Add-Type -AssemblyName System.Windows.Forms, System.Drawing

# Thresholds
$ISR_warn        = 1000; $ISR_crit        = 3000
$DPC_warn        = 2000; $DPC_crit        = 5000
$PerCpu_ISR_warn = 500;  $PerCpu_ISR_crit = 1500
$PerCpu_DPC_warn = 1000; $PerCpu_DPC_crit = 2500

function Get-StatusColor {
    param($value, $warnLimit, $critLimit)
    if ($value -lt 15000)     { "Green" }
    elseif ($value -lt 30000) { "Yellow" }
    else                      { "Red" }
}


# Load results
try {
    $result = Get-Content $JsonFile -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
}
catch {
    [System.Windows.Forms.MessageBox]::Show("Error loading results: $_", "Error", "OK", "Error")
    exit
}

# Load old results if available
$lastResultFile = "last_result.json"
$oldResult = $null
if (Test-Path $lastResultFile) {
    try {
        $oldResult = Get-Content $lastResultFile -Encoding UTF8 | ConvertFrom-Json
    } catch {
        Write-Warning "Error loading last results: $_"
    }
}

# Extract current results
$isr_total    = $result.isr_total
$dpc_total    = $result.dpc_total
$intervalTime = $result.intervalTime
$dpcImpact    = $result.dpcImpact
$isrImpact    = $result.isrImpact
$totalImpact  = $result.totalImpact
$fullReport   = $result.fullReport
$isrDrivers   = $result.isrDrivers | Sort-Object Value -Descending
$dpcDrivers   = $result.dpcDrivers | Sort-Object Value -Descending

# Calculate per-CPU values
$maxISRPerCpu = if ($isrDrivers) { ($isrDrivers.Value | Measure-Object -Maximum).Maximum } else { 0 }
$maxDPCPerCpu = if ($dpcDrivers) { ($dpcDrivers.Value | Measure-Object -Maximum).Maximum } else { 0 }

# Old values for comparison
$old_isr_total    = if ($oldResult) { $oldResult.isr_total } else { $null }
$old_dpc_total    = if ($oldResult) { $oldResult.dpc_total } else { $null }
$old_maxISRPerCpu = if ($oldResult) { $oldResult.maxISRPerCpu } else { $null }
$old_maxDPCPerCpu = if ($oldResult) { $oldResult.maxDPCPerCpu } else { $null }

function Get-OverallStatus {
    $status  = "Good (Green)"
    $reasons = @()
    
    if ($maxISRPerCpu -ge $PerCpu_ISR_crit) {
        $status = "Critical (Red)"
        $reasons += "ISR per CPU: $maxISRPerCpu us"
    }
    elseif ($maxISRPerCpu -ge $PerCpu_ISR_warn) {
        $status = "Warning (Yellow)"
        $reasons += "ISR per CPU: $maxISRPerCpu us"
    }
    
    if ($maxDPCPerCpu -ge $PerCpu_DPC_crit) {
        if ($status -eq "Good (Green)") { $status = "Critical (Red)" }
        $reasons += "DPC per CPU: $maxDPCPerCpu us"
    }
    elseif ($maxDPCPerCpu -ge $PerCpu_DPC_warn) {
        if ($status -eq "Good (Green)") { $status = "Warning (Yellow)" }
        $reasons += "DPC per CPU: $maxDPCPerCpu us"
    }
    
    if ($reasons.Count) { $status += "`r`nReason: " + ($reasons -join ", ") }
    return $status
}

# Build GUI with dark design
$form = New-Object System.Windows.Forms.Form
$form.Text          = "DPC/ISR Analyzer - GUI by JACKPOT_ZB $((Get-Item $JsonFile).BaseName)"
$form.Size          = New-Object System.Drawing.Size(1000,750)  # Höhe vergrößert
$form.StartPosition = "CenterScreen"
$form.BackColor     = [System.Drawing.Color]::FromArgb(45,45,48)
$form.ForeColor     = [System.Drawing.Color]::White

# Font
$font = New-Object System.Drawing.Font("Segoe UI",10)

# --- Top: Grid with comparison data ---
$tlp = New-Object System.Windows.Forms.TableLayoutPanel
$tlp.RowCount     = 4
$tlp.ColumnCount  = 4
$tlp.AutoSize     = $true
$tlp.AutoSizeMode = 'GrowAndShrink'
$tlp.BackColor    = [System.Drawing.Color]::FromArgb(45,45,48)
$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,25)))
$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,25)))
$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,25)))
$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,25)))
for ($i = 0; $i -lt 4; $i++) {
    # Deutlich vergrößerte Zeilenhöhe
    $tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 45)))
}

function Add-GridRow($label, $currentValue, $oldValue, $warn, $crit, $row) {
    $lblDesc = New-Object System.Windows.Forms.Label
    $lblDesc.Height     = 40
    $lblDesc.Text       = $label
    $lblDesc.Font       = $font
    $lblDesc.ForeColor  = [System.Drawing.Color]::White
    $lblDesc.TextAlign  = [System.Drawing.ContentAlignment]::MiddleLeft
    $tlp.Controls.Add($lblDesc, 0, $row)

    $lblCurrent = New-Object System.Windows.Forms.Label
    $lblCurrent.Height     = 40
    $lblCurrent.Text       = "$($currentValue.ToString('N2')) us"
    $lblCurrent.Font       = $font
    $lblCurrent.ForeColor  = [System.Drawing.Color]::LightGray
    $lblCurrent.TextAlign  = [System.Drawing.ContentAlignment]::MiddleRight
    $tlp.Controls.Add($lblCurrent, 1, $row)

    $lblDiff = New-Object System.Windows.Forms.Label
    $lblDiff.Height     = 40
    $lblDiff.Font       = $font
    $lblDiff.TextAlign  = [System.Drawing.ContentAlignment]::MiddleRight
    
    if ($null -ne $oldValue) {
        $diff = $currentValue - $oldValue
        if ($diff -ne 0) {
            $sign = if ($diff -gt 0) { "+" } else { "" }
            $lblDiff.Text = "$($sign)$($diff.ToString('N2')) us"
            $lblDiff.ForeColor = if ($diff -lt 0) { [System.Drawing.Color]::Green } else { [System.Drawing.Color]::Red }
        } else {
            $lblDiff.Text = "No change"
            $lblDiff.ForeColor = [System.Drawing.Color]::LightGray
        }
    } else {
        $lblDiff.Text = "No previous data"
        $lblDiff.ForeColor = [System.Drawing.Color]::LightGray
    }
    
    $tlp.Controls.Add($lblDiff, 2, $row)

    $p = New-Object System.Windows.Forms.Panel
    $p.Size      = New-Object System.Drawing.Size(20,20)
    $p.BackColor = [System.Drawing.Color]::FromName((Get-StatusColor $currentValue $warn $crit))
    $p.Top       = 12
    $tlp.Controls.Add($p, 3, $row)
}

Add-GridRow "ISR-Time total"    $isr_total    $old_isr_total    $ISR_warn        $ISR_crit         0
Add-GridRow "DPC-Time total"    $dpc_total    $old_dpc_total    $DPC_warn        $DPC_crit         1
Add-GridRow "Max ISR per CPU"   $maxISRPerCpu $old_maxISRPerCpu $PerCpu_ISR_warn $PerCpu_ISR_crit  2
Add-GridRow "Max DPC per CPU"   $maxDPCPerCpu $old_maxDPCPerCpu $PerCpu_DPC_warn $PerCpu_DPC_crit  3

# --- Middle: TabControl for ISR and DPC drivers ---
$tabControl = New-Object System.Windows.Forms.TabControl
$tabControl.Dock = 'Fill'
$tabControl.BackColor = [System.Drawing.Color]::FromArgb(45,45,48)
$tabControl.ForeColor = [System.Drawing.Color]::White

# TabPage for ISR drivers
$tabISR = New-Object System.Windows.Forms.TabPage
$tabISR.Text = "ISR Drivers"
$tabISR.BackColor = [System.Drawing.Color]::FromArgb(45,45,48)
$tabISR.ForeColor = [System.Drawing.Color]::White
$tabISR.Padding = New-Object System.Windows.Forms.Padding(5)
$tabControl.Controls.Add($tabISR)

# TabPage for DPC drivers
$tabDPC = New-Object System.Windows.Forms.TabPage
$tabDPC.Text = "DPC Drivers"
$tabDPC.BackColor = [System.Drawing.Color]::FromArgb(45,45,48)
$tabDPC.ForeColor = [System.Drawing.Color]::White
$tabDPC.Padding = New-Object System.Windows.Forms.Padding(5)
$tabControl.Controls.Add($tabDPC)

# Function to create DataGridView with dark design and larger font
function Create-DataGridView {
    param($drivers, $oldDrivers)
    
    $dgv = New-Object System.Windows.Forms.DataGridView
    $dgv.Dock = 'Fill'
    $dgv.AutoSizeColumnsMode = 'Fill'
    $dgv.BackgroundColor = [System.Drawing.Color]::FromArgb(30,30,30)
    $dgv.ForeColor = [System.Drawing.Color]::White
    $dgv.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(45,45,48)
    $dgv.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::White
    $dgv.RowHeadersVisible = $false
    $dgv.SelectionMode = 'FullRowSelect'
    $dgv.MultiSelect = $false
    $dgv.ReadOnly = $true
    $dgv.AllowUserToAddRows = $false
    $dgv.AllowUserToDeleteRows = $false
    $dgv.RowTemplate.Height = 36  # Höher für bessere Lesbarkeit
    
    # Größere Schrift
    $cellFont = New-Object System.Drawing.Font("Segoe UI", 11)
    $headerFont = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
    
    $dgv.DefaultCellStyle.Font = $cellFont
    $dgv.ColumnHeadersDefaultCellStyle.Font = $headerFont
    $dgv.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(40,40,40)

    # Set default colors for better contrast
    $dgv.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(30,30,30)
    $dgv.DefaultCellStyle.ForeColor = [System.Drawing.Color]::LightGray
    $dgv.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(60,60,100)
    $dgv.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White

    $dgv.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(40,40,40)
    $dgv.AlternatingRowsDefaultCellStyle.ForeColor = [System.Drawing.Color]::LightGray
    $dgv.AlternatingRowsDefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(70,70,110)
    $dgv.AlternatingRowsDefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White

    # Add columns
    $colDriver = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colDriver.HeaderText = "Driver"
    $colDriver.Name = "Driver"
    $colDriver.ReadOnly = $true
    $colDriver.FillWeight = 40
    $dgv.Columns.Add($colDriver) | Out-Null

    $colCurrent = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colCurrent.HeaderText = "Current (us)"
    $colCurrent.Name = "Current"
    $colCurrent.ReadOnly = $true
    $colCurrent.DefaultCellStyle.Alignment = 'MiddleRight'
    $colCurrent.FillWeight = 20
    $dgv.Columns.Add($colCurrent) | Out-Null

    $colPrevious = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colPrevious.HeaderText = "Previous (us)"
    $colPrevious.Name = "Previous"
    $colPrevious.ReadOnly = $true
    $colPrevious.DefaultCellStyle.Alignment = 'MiddleRight'
    $colPrevious.FillWeight = 20
    $dgv.Columns.Add($colPrevious) | Out-Null

    $colChange = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colChange.HeaderText = "Change (us)"
    $colChange.Name = "Change"
    $colChange.ReadOnly = $true
    $colChange.DefaultCellStyle.Alignment = 'MiddleRight'
    $colChange.FillWeight = 20
    $dgv.Columns.Add($colChange) | Out-Null

    foreach ($d in $drivers) {
        $oldValue = $null
        if ($oldDrivers) {
            $oldDriver = $oldDrivers | Where-Object { $_.Module -eq $d.Module } | Select-Object -First 1
            if ($oldDriver) {
                $oldValue = $oldDriver.Value
            }
        }

        $row = $dgv.Rows.Add()
        $dgv.Rows[$row].Cells[0].Value = $d.Module
        $dgv.Rows[$row].Cells[1].Value = $d.Value.ToString("N2")
        
        if ($null -ne $oldValue) {
            $dgv.Rows[$row].Cells[2].Value = $oldValue.ToString("N2")
            $diff = $d.Value - $oldValue
            $sign = if ($diff -gt 0) { "+" } else { "" }
            $dgv.Rows[$row].Cells[3].Value = "$($sign)$($diff.ToString("N2"))"
            if ($diff -lt 0) {
                $dgv.Rows[$row].Cells[3].Style.ForeColor = [System.Drawing.Color]::Green
            } else {
                $dgv.Rows[$row].Cells[3].Style.ForeColor = [System.Drawing.Color]::Red
            }
        } else {
            $dgv.Rows[$row].Cells[2].Value = "N/A"
            $dgv.Rows[$row].Cells[3].Value = "N/A"
        }
    }

    return $dgv
}

# ISR-DataGridView
$isrOldDrivers = if ($oldResult -and $oldResult.isrDrivers) { $oldResult.isrDrivers } else { $null }
$dgvISR = Create-DataGridView $isrDrivers $isrOldDrivers
$tabISR.Controls.Add($dgvISR)

# DPC-DataGridView
$dpcOldDrivers = if ($oldResult -and $oldResult.dpcDrivers) { $oldResult.dpcDrivers } else { $null }
$dgvDPC = Create-DataGridView $dpcDrivers $dpcOldDrivers
$tabDPC.Controls.Add($dgvDPC)

# --- System Status ---
$statusText = "System Status:`r`n" + (Get-OverallStatus)
$statusLines = ($statusText -split "`r`n").Count

$statusBox = New-Object System.Windows.Forms.TextBox
$statusBox.Multiline  = $true
$statusBox.ReadOnly   = $true
$statusBox.ScrollBars = 'Vertical'
$statusBox.Dock       = 'Bottom'
$statusBox.Height     = [Math]::Min([Math]::Max($statusLines * 30, 80), 160) # Höher
$statusBox.Font       = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$statusBox.Text       = $statusText

# Farbliche Hervorhebung basierend auf Status
if ($statusText -match "Critical") {
    $statusBox.BackColor = [System.Drawing.Color]::FromArgb(70, 0, 0)
    $statusBox.ForeColor = [System.Drawing.Color]::LightCoral
} elseif ($statusText -match "Warning") {
    $statusBox.BackColor = [System.Drawing.Color]::FromArgb(70, 70, 0)
    $statusBox.ForeColor = [System.Drawing.Color]::LightYellow
} else {
    $statusBox.BackColor = [System.Drawing.Color]::FromArgb(0, 50, 0)
    $statusBox.ForeColor = [System.Drawing.Color]::LightGreen
}

# --- Report Textbox ---
$reportBox = New-Object System.Windows.Forms.TextBox
$reportBox.Multiline  = $true
$reportBox.ReadOnly   = $true
$reportBox.ScrollBars = 'Both'
$reportBox.Dock       = 'Bottom'
$reportBox.Height     = 240  # Höher
$reportBox.Font       = New-Object System.Drawing.Font("Consolas", 10)
$reportBox.BackColor  = [System.Drawing.Color]::FromArgb(30,30,30)
$reportBox.ForeColor  = [System.Drawing.Color]::LightGray
$reportBox.Text       = $fullReport

# Impact information
$impactGroup = New-Object System.Windows.Forms.GroupBox
$impactGroup.Text = "DPC/ISR Impact"
$impactGroup.ForeColor = [System.Drawing.Color]::White
$impactGroup.Dock = "Top"
$impactGroup.Height = 90  # Höher
$impactGroup.BackColor = [System.Drawing.Color]::FromArgb(45,45,48)  # Hintergrundfarbe angepasst

$impactLayout = New-Object System.Windows.Forms.TableLayoutPanel
$impactLayout.Dock = "Fill"
$impactLayout.ColumnCount = 3
$impactLayout.RowCount = 1
$impactLayout.BackColor = [System.Drawing.Color]::FromArgb(45,45,48)  # Hintergrundfarbe angepasst

$labels = @(
    "DPC Impact: $($result.dpcImpact.ToString('N3'))%",
    "ISR Impact: $($result.isrImpact.ToString('N3'))%",
    "Total Impact: $($result.totalImpact.ToString('N3'))% | $($($result.dpc_total + $result.isr_total) / 1000) ms"
)

foreach ($i in 0..2) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $labels[$i]
    $label.TextAlign = "MiddleCenter"
    $label.Dock = "Fill"
    $label.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $label.Height = 70  # Höher
    
    if ($i -eq 0) { $label.ForeColor = if ($result.dpcImpact -gt 0.5) { [System.Drawing.Color]::Red } else { [System.Drawing.Color]::LightGreen } }
    if ($i -eq 1) { $label.ForeColor = if ($result.isrImpact -gt 0.3) { [System.Drawing.Color]::Red } else { [System.Drawing.Color]::LightGreen } }
    if ($i -eq 2) { $label.ForeColor = if ($result.totalImpact -gt 0.8) { [System.Drawing.Color]::Red } else { [System.Drawing.Color]::LightGreen } }
    
    $impactLayout.Controls.Add($label, $i, 0)
}

$impactGroup.Controls.Add($impactLayout)

# --- Main Layout with Splitter ---
$mainSplitter = New-Object System.Windows.Forms.SplitContainer
$mainSplitter.Orientation = "Horizontal"
$mainSplitter.Dock = "Fill"
$mainSplitter.SplitterWidth = 8
$mainSplitter.BackColor = [System.Drawing.Color]::FromArgb(45,45,48)  # Hintergrundfarbe angepasst
$mainSplitter.SplitterDistance = 200  # Mehr Platz für die obere Zusammenfassung
$mainSplitter.Panel1MinSize = 180
$mainSplitter.Panel2MinSize = 100  # Korrigierte Mindestgröße

# Top panel: Summary
$topPanel = New-Object System.Windows.Forms.Panel
$topPanel.Dock = "Fill"
$topPanel.AutoScroll = $true
$topPanel.BackColor = [System.Drawing.Color]::FromArgb(45,45,48)  # Hintergrundfarbe angepasst
$topPanel.Controls.Add($tlp)
$mainSplitter.Panel1.Controls.Add($topPanel)

# Bottom panel: TabControl with drivers
$tabContainer = New-Object System.Windows.Forms.Panel
$tabContainer.Dock = "Fill"
$tabContainer.BackColor = [System.Drawing.Color]::FromArgb(45,45,48)  # Hintergrundfarbe angepasst
$tabContainer.Controls.Add($tabControl)
$mainSplitter.Panel2.Controls.Add($tabContainer)

# --- Form Layout ---
$form.Controls.Add($impactGroup)
$form.Controls.Add($mainSplitter)
$form.Controls.Add($statusBox)
$form.Controls.Add($reportBox)

# Save results on exit
$form.Add_FormClosed({
    $saveData = [PSCustomObject]@{
        isr_total    = $isr_total
        dpc_total    = $dpc_total
        maxISRPerCpu = $maxISRPerCpu
        maxDPCPerCpu = $maxDPCPerCpu
        isrDrivers   = $isrDrivers
        dpcDrivers   = $dpcDrivers
    }
    $saveData | ConvertTo-Json | Out-File $lastResultFile -Encoding UTF8
})

# Confirm on close
$form.Add_FormClosing({
    $result = [System.Windows.Forms.MessageBox]::Show("Do you really want to close the analysis?", "Confirmation", "YesNo", "Question")
    if ($result -eq "No") {
        $_.Cancel = $true
    }
})

# Show form
$form.Add_Shown({ $form.Activate() })
[void]$form.ShowDialog()