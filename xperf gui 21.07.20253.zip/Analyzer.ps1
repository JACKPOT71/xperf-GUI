param (
    [int]$Duration = 0,
    [int]$Delay = 0
)

# Admin check
$admin = [bool](([System.Security.Principal.WindowsIdentity]::GetCurrent()).Groups -match "S-1-5-32-544")
if (!$admin) {
    Write-Host "Please run as Administrator!" -ForegroundColor Red
    pause
    exit 1
}

# Paths
$xperfPath = Join-Path $PSScriptRoot "xperf\xperf.exe"
if (-not (Test-Path $xperfPath)) {
    Write-Host "xperf.exe not found!" -ForegroundColor Red
    pause
    exit 1
}

# Script made by JACKPOT_ZB
function Replace-Umlauts {
    param([string]$text)
    $text = $text -replace 'ä','ae'
    $text = $text -replace 'ö','oe'
    $text = $text -replace 'ü','ue'
    $text = $text -replace 'ß','ss'
    $text = $text -replace 'Ä','Ae'
    $text = $text -replace 'Ö','Oe'
    $text = $text -replace 'Ü','Ue'
    return $text
}

# Menu for duration selection
if ($Duration -eq 0) {
    Clear-Host
    Write-Host "`n=== Measurement Duration Selection ==="
    Write-Host "1: 10 seconds"
    Write-Host "2: 30 seconds"
    Write-Host "3: 60 seconds"
    Write-Host "4: Custom duration"
    $choice = Read-Host "`nEnter your choice (1-4)"
    
    switch ($choice) {
        '1' { $Duration = 10 }
        '2' { $Duration = 30 }
        '3' { $Duration = 60 }
        '4' { 
            $custom = Read-Host "Enter custom duration in seconds"
            if (-not [int]::TryParse($custom, [ref]$Duration)) {
                Write-Host "Invalid input. Using default 10 seconds." -ForegroundColor Yellow
                $Duration = 10
            }
        }
        default {
            Write-Host "Invalid choice. Using default 10 seconds." -ForegroundColor Yellow
            $Duration = 10
        }
    }
}

# Menu for delay selection
if ($Delay -eq 0) {
    Clear-Host
    Write-Host "`n=== Measurement Delay Selection ==="
    Write-Host "1: No delay (start immediately)"
    Write-Host "2: 3 seconds delay"
    Write-Host "3: 5 seconds delay"
    Write-Host "4: 10 seconds delay"
    Write-Host "5: Custom delay"
    $choice = Read-Host "`nEnter your choice (1-5)"
    
    switch ($choice) {
        '1' { $Delay = 0 }
        '2' { $Delay = 3 }
        '3' { $Delay = 5 }
        '4' { $Delay = 10 }
        '5' { 
            $custom = Read-Host "Enter custom delay in seconds"
            if (-not [int]::TryParse($custom, [ref]$Delay)) {
                Write-Host "Invalid input. Using no delay." -ForegroundColor Yellow
                $Delay = 0
            }
        }
        default {
            Write-Host "Invalid choice. Using no delay." -ForegroundColor Yellow
            $Delay = 0
        }
    }
}

# Apply delay if selected
if ($Delay -gt 0) {
    Write-Host "`nWaiting for $Delay seconds before measurement..." -ForegroundColor Cyan
    Start-Sleep -Seconds $Delay
}

# Temporary files
$id = Get-Date -Format "yyyyMMdd-HHmmss"
$etlFile = "dpc_trace_$id.etl"
$txtFile = "dpc_trace_$id.txt"
$outputFile = "DPC-ISR-Analysis_$id.txt"
$jsonFile = "last_result_$id.json"

$guiStarted = $false

try {
    # Stop all sessions
    Start-Process $xperfPath -ArgumentList "-stop" -Wait -WindowStyle Hidden -ErrorAction Stop | Out-Null
    
    # Start recording
    Write-Host "Starting measurement for $Duration seconds..." -ForegroundColor Cyan
    Start-Process $xperfPath -ArgumentList "-on", "PROC_THREAD+LOADER+DPC+INTERRUPT" -Wait -WindowStyle Hidden -ErrorAction Stop | Out-Null
    
    # Wait
    Start-Sleep -Seconds $Duration
    
    # Stop recording
    Write-Host "Stopping measurement..." -ForegroundColor Cyan
    Start-Process $xperfPath -ArgumentList "-d", $etlFile, "-stop" -Wait -WindowStyle Hidden -ErrorAction Stop | Out-Null
    
    # Convert to text
    Write-Host "Converting data..." -ForegroundColor Cyan
    Start-Process $xperfPath -ArgumentList "-i", $etlFile, "-a", "dpcisr" -RedirectStandardOutput $txtFile -Wait -WindowStyle Hidden -ErrorAction Stop | Out-Null
    
    # Analyze output
    $content = Get-Content $txtFile -Raw
    
    # Extract total time
    $intervalTime = 0
    if ($content -match "CPU Usage from \d+ us to (\d+) us") {
        $intervalTime = [double]$matches[1]
    }
    
    # Extract DPC data
    $dpcData = @{}
    if ($content -match "(?s)DPC Info.*?Module(.*?)Total = \d+") {
        $table = $matches[1].Trim()
        foreach ($line in $table -split "`r?`n") {
            if ($line -match "(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*([^,]+)$") {
                $total = 0
                for ($i = 1; $i -le 8; $i++) {
                    $val = $matches[$i].Trim().Split(' ')[0]
                    if ([double]::TryParse($val, [ref]$null)) {
                        $total += [double]$val
                    }
                }
                $module = $matches[9].Trim()
                $dpcData[$module] = $total
            }
        }
    }
    
    # Extract ISR data
    $isrData = @{}
    if ($content -match "(?s)Interrupt Info.*?Module(.*?)Total = \d+") {
        $table = $matches[1].Trim()
        foreach ($line in $table -split "`r?`n") {
            if ($line -match "(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*(\d+.*?)\s*,\s*([^,]+)$") {
                $total = 0
                for ($i = 1; $i -le 8; $i++) {
                    $val = $matches[$i].Trim().Split(' ')[0]
                    if ([double]::TryParse($val, [ref]$null)) {
                        $total += [double]$val
                    }
                }
                $module = $matches[9].Trim()
                $isrData[$module] = $total
            }
        }
    }
    
    # Calculate impact
    $dpcTotal = ($dpcData.Values | Measure-Object -Sum).Sum
    $isrTotal = ($isrData.Values | Measure-Object -Sum).Sum
    
    $dpcImpact = if ($intervalTime -gt 0) { [Math]::Round(($dpcTotal / $intervalTime) * 100, 3) } else { 0 }
    $isrImpact = if ($intervalTime -gt 0) { [Math]::Round(($isrTotal / $intervalTime) * 100, 3) } else { 0 }
    $totalImpact = $dpcImpact + $isrImpact
    
    # Generate report
    $report = @()
    $report += "----- Total DPC -----"
    foreach ($key in $dpcData.Keys) {
        $report += "$key -> $($dpcData[$key])"
    }
    $report += ""
    $report += "----- Total ISR -----"
    foreach ($key in $isrData.Keys) {
        $report += "$key -> $($isrData[$key])"
    }
    $report += ""
    $report += "----- DPC/ISR Effective Impact (%) -----"
    $report += "DPC Impact (%): $dpcImpact"
    $report += "ISR Impact (%): $isrImpact"
    $report += "Total Impact (%): $totalImpact"
    $report += ""
    $report += "----- Data -----"
    $report += "Total Interval Time (us): $intervalTime"
    $report += "Total DPC Time: $dpcTotal"
    $report += "Total ISR Time: $isrTotal"
    $report += "Module DPC Count: $($dpcData.Count)"
    $report += "Module ISR Count: $($isrData.Count)"
    
    # Replace umlauts
    $report = $report | ForEach-Object { Replace-Umlauts $_ }
    
    # Save output
    $report | Out-File $outputFile -Encoding UTF8
    Write-Host "`nResults saved in: $outputFile`n" -ForegroundColor Green
    
    # Prepare data for GUI
    $resultData = @{
        isr_total    = $isrTotal
        dpc_total    = $dpcTotal
        intervalTime = $intervalTime
        dpcImpact    = $dpcImpact
        isrImpact    = $isrImpact
        totalImpact  = $totalImpact
        isrDrivers   = @($isrData.GetEnumerator() | ForEach-Object { [PSCustomObject]@{Module = $_.Key; Value = $_.Value} })
        dpcDrivers   = @($dpcData.GetEnumerator() | ForEach-Object { [PSCustomObject]@{Module = $_.Key; Value = $_.Value} })
        fullReport   = $report -join "`r`n"
    }
    
    # Save data for GUI
    $resultData | ConvertTo-Json | Out-File $jsonFile -Encoding UTF8
    
    # Start GUI
    Write-Host "Starting GUI to display results..." -ForegroundColor Cyan
    $process = Start-Process PowerShell -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-NoExit", "-File", "`"$PSScriptRoot\Show-DPCISR_GUI.ps1`"", "`"$jsonFile`"" -PassThru -Wait
    $guiStarted = $true
}
catch {
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}
finally {
    # Cleanup
    if (Test-Path $etlFile) { Remove-Item $etlFile -ErrorAction SilentlyContinue }
    if (Test-Path $txtFile) { Remove-Item $txtFile -ErrorAction SilentlyContinue }
    
    # Pause only if GUI not started
    if (-not $guiStarted) {
        Write-Host "`nPress any key..." -ForegroundColor Cyan
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    }
}