# --- Datei: Show-DPCISR_GUI.ps1 (FINAL v5 - Vollendetes Design) ---

param(
    [string]$JsonFile
)
$env:POWERSHELL_UPDATECHECK = 'Off'
if (-not (Test-Path $JsonFile)) { [System.Windows.Forms.MessageBox]::Show("Result file not found!`n$JsonFile", "Error", "OK", "Error"); exit 1 }

Add-Type -AssemblyName System.Windows.Forms, System.Drawing

# Code für Dark-Mode Titelleiste (Stabil)
$cSharpSource = @"
using System; using System.Runtime.InteropServices;
public static class DwmApi {
    [DllImport("dwmapi.dll", PreserveSig = true)]
    public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);
    public const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;
}
"@
Add-Type -TypeDefinition $cSharpSource -Language CSharp -ErrorAction SilentlyContinue

# Angepasste Schwellenwerte
$ISR_warn = 4500; $ISR_crit = 7000; $DPC_warn = 4500; $DPC_crit = 7000
$PerCpu_ISR_warn = 4500; $PerCpu_ISR_crit = 7000; $PerCpu_DPC_warn = 4500; $PerCpu_DPC_crit = 7000

# Funktionen und Daten laden
function Get-StatusColor { param($value, $warnLimit, $critLimit); if ($value -ge $critLimit) { return "Red" } if ($value -ge $warnLimit) { return "Yellow" }; return "Green" }
try { $result = Get-Content $JsonFile -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch { [System.Windows.Forms.MessageBox]::Show("Error loading results: $_", "Error", "OK", "Error"); exit }
$lastResultFile = Join-Path $PSScriptRoot "last_result.json"; $oldResult = $null; if (Test-Path $lastResultFile) { try { $oldResult = Get-Content $lastResultFile -Encoding UTF8 | ConvertFrom-Json } catch { Write-Warning "Error loading last results: $_" } }
$isr_total = $result.isr_total; $dpc_total = $result.dpc_total; $isrDrivers = $result.isrDrivers | Sort-Object Value -Descending; $dpcDrivers = $result.dpcDrivers | Sort-Object Value -Descending
$maxISRPerCpu = if ($isrDrivers.Count -gt 0) { ($isrDrivers.Value | Measure-Object -Maximum).Maximum } else { 0 }; $maxDPCPerCpu = if ($dpcDrivers.Count -gt 0) { ($dpcDrivers.Value | Measure-Object -Maximum).Maximum } else { 0 }
$old_isr_total = if ($oldResult) { $oldResult.isr_total } else { $null }; $old_dpc_total = if ($oldResult) { $oldResult.dpc_total } else { $null }; $old_maxISRPerCpu = if ($oldResult) { $oldResult.maxISRPerCpu } else { $null }; $old_maxDPCPerCpu = if ($oldResult) { $oldResult.maxDPCPerCpu } else { $null }

function Get-OverallStatus {
    $isCritical = $false; $isWarning = $false; $reasons = @()
    if ($maxISRPerCpu -ge $PerCpu_ISR_crit) { $isCritical = $true; $reasons += "Max ISR per CPU: $($maxISRPerCpu.ToString('N0')) us (Critical > $($PerCpu_ISR_crit.ToString('N0')))" } elseif ($maxISRPerCpu -ge $PerCpu_ISR_warn) { $isWarning = $true; $reasons += "Max ISR per CPU: $($maxISRPerCpu.ToString('N0')) us (Warning > $($PerCpu_ISR_warn.ToString('N0')))" }
    if ($maxDPCPerCpu -ge $PerCpu_DPC_crit) { $isCritical = $true; $reasons += "Max DPC per CPU: $($maxDPCPerCpu.ToString('N0')) us (Critical > $($PerCpu_DPC_crit.ToString('N0')))" } elseif ($maxDPCPerCpu -ge $PerCpu_DPC_warn) { $isWarning = $true; $reasons += "Max DPC per CPU: $($maxDPCPerCpu.ToString('N0')) us (Warning > $($PerCpu_DPC_warn.ToString('N0')))" }
    if ($isCritical) { return "Critical (Red)`r`nReason: " + ($reasons -join ", ") } elseif ($isWarning) { return "Warning (Yellow)`r`nReason: " + ($reasons -join ", ") } else { return "Good (Green)`r`nReason: All values are within your defined limits." }
}

# --- GUI Aufbau ---
$darkColor = [System.Drawing.Color]::FromArgb(45, 45, 48)
$lightDarkColor = [System.Drawing.Color]::FromArgb(60, 60, 63)
$font = New-Object System.Drawing.Font("Segoe UI", 10)

$form = New-Object System.Windows.Forms.Form; $form.Text = "DPC/ISR Analyzer - GUI by JACKPOT_ZB $((Get-Item $JsonFile).BaseName)"; $form.Size = New-Object System.Drawing.Size(1000, 800); $form.StartPosition = "CenterScreen"; $form.BackColor = $darkColor; $form.ForeColor = [System.Drawing.Color]::White

# --- NEU: GroupBox durch Panel und Label ersetzt ---
$impactPanel = New-Object System.Windows.Forms.Panel; $impactPanel.Dock = "Top"; $impactPanel.Height = 80; $impactPanel.BackColor = $darkColor
$impactLabel = New-Object System.Windows.Forms.Label; $impactLabel.Text = "DPC/ISR Impact"; $impactLabel.Location = New-Object System.Drawing.Point(8, 4); $impactLabel.ForeColor = [System.Drawing.Color]::White; $impactLabel.Font = $font
$impactPanel.Controls.Add($impactLabel)
$impactLayout = New-Object System.Windows.Forms.TableLayoutPanel; $impactLayout.Dock = "Fill"; $impactLayout.ColumnCount = 3; $impactLayout.RowCount = 1; $impactLayout.BackColor = $darkColor; $impactLayout.Padding = New-Object System.Windows.Forms.Padding(0, 20, 0, 0)
$labels = @("DPC Impact: $($result.dpcImpact.ToString('N3'))%", "ISR Impact: $($result.isrImpact.ToString('N3'))%", "Total Impact: $($result.totalImpact.ToString('N3'))% | $($($result.dpc_total + $result.isr_total) / 1000) ms"); foreach ($i in 0..2) { $label = New-Object System.Windows.Forms.Label; $label.Text = $labels[$i]; $label.TextAlign = "MiddleCenter"; $label.Dock = "Fill"; $label.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold); if ($i -eq 0) { $label.ForeColor = if ($result.dpcImpact -gt 0.5) { [System.Drawing.Color]::LightCoral } else { [System.Drawing.Color]::LightGreen } }; if ($i -eq 1) { $label.ForeColor = if ($result.isrImpact -gt 0.3) { [System.Drawing.Color]::LightCoral } else { [System.Drawing.Color]::LightGreen } }; if ($i -eq 2) { $label.ForeColor = if ($result.totalImpact -gt 0.8) { [System.Drawing.Color]::LightCoral } else { [System.Drawing.Color]::LightGreen } }; $impactLayout.Controls.Add($label, $i, 0) | Out-Null }
$impactPanel.Controls.Add($impactLayout)

# Top-Grid (unverändert)
$tlp = New-Object System.Windows.Forms.TableLayoutPanel; $tlp.RowCount = 4; $tlp.ColumnCount = 4; $tlp.Dock = 'Fill'; $tlp.BackColor = $darkColor; $tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 35))) | Out-Null; $tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 25)))| Out-Null; $tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 25)))| Out-Null; $tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 15)))| Out-Null; for ($i = 0; $i -lt 4; $i++) { $tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 45))) | Out-Null }
function Add-GridRow($label, $currentValue, $oldValue, $warn, $crit, $row) { $lblDesc = New-Object System.Windows.Forms.Label; $lblDesc.Height = 40; $lblDesc.Text = $label; $lblDesc.Font = $font; $lblDesc.ForeColor = [System.Drawing.Color]::White; $lblDesc.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft; $tlp.Controls.Add($lblDesc, 0, $row); $lblCurrent = New-Object System.Windows.Forms.Label; $lblCurrent.Height = 40; $lblCurrent.Text = "$($currentValue.ToString('N0')) us"; $lblCurrent.Font = $font; $lblCurrent.ForeColor = [System.Drawing.Color]::LightGray; $lblCurrent.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight; $tlp.Controls.Add($lblCurrent, 1, $row); $lblDiff = New-Object System.Windows.Forms.Label; $lblDiff.Height = 40; $lblDiff.Font = $font; $lblDiff.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight; if ($null -ne $oldValue) { $diff = $currentValue - $oldValue; if ($diff -ne 0) { $sign = if ($diff -gt 0) { "+" } else { "" }; $lblDiff.Text = "$($sign)$($diff.ToString('N0')) us"; $lblDiff.ForeColor = if ($diff -lt 0) { [System.Drawing.Color]::LightGreen } else { [System.Drawing.Color]::LightCoral } } else { $lblDiff.Text = "No change"; $lblDiff.ForeColor = [System.Drawing.Color]::LightGray } } else { $lblDiff.Text = "No previous data"; $lblDiff.ForeColor = [System.Drawing.Color]::LightGray }; $tlp.Controls.Add($lblDiff, 2, $row); $p = New-Object System.Windows.Forms.Panel; $p.Size = New-Object System.Drawing.Size(20, 20); $p.BackColor = [System.Drawing.Color]::FromName((Get-StatusColor $currentValue $warn $crit)); $p.Margin = New-Object System.Windows.Forms.Padding(10, 12, 3, 3); $tlp.Controls.Add($p, 3, $row) }
Add-GridRow "ISR-Time total" $isr_total $old_isr_total $ISR_warn $ISR_crit 0; Add-GridRow "DPC-Time total" $dpc_total $old_dpc_total $DPC_warn $DPC_crit 1; Add-GridRow "Max ISR per CPU" $maxISRPerCpu $old_maxISRPerCpu $PerCpu_ISR_warn $PerCpu_ISR_crit 2; Add-GridRow "Max DPC per CPU" $maxDPCPerCpu $old_maxDPCPerCpu $PerCpu_DPC_warn $PerCpu_DPC_crit 3

# DataGridViews erstellen (unverändert)
function Create-DataGridView { param($drivers, $oldDrivers) ; $dgv = New-Object System.Windows.Forms.DataGridView; $dgv.Dock = 'Fill'; $dgv.AutoSizeColumnsMode = 'Fill'; $dgv.BackgroundColor = [System.Drawing.Color]::FromArgb(30, 30, 30); $dgv.ForeColor = [System.Drawing.Color]::White; $dgv.ColumnHeadersDefaultCellStyle.BackColor = $darkColor; $dgv.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::White; $dgv.RowHeadersVisible = $false; $dgv.SelectionMode = 'FullRowSelect'; $dgv.MultiSelect = $false; $dgv.ReadOnly = $true; $dgv.AllowUserToAddRows = $false; $dgv.AllowUserToDeleteRows = $false; $dgv.RowTemplate.Height = 36; $cellFont = New-Object System.Drawing.Font("Segoe UI", 11); $headerFont = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold); $dgv.DefaultCellStyle.Font = $cellFont; $dgv.ColumnHeadersDefaultCellStyle.Font = $headerFont; $dgv.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(40, 40, 40); $dgv.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30); $dgv.DefaultCellStyle.ForeColor = [System.Drawing.Color]::LightGray; $dgv.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(60, 60, 100); $dgv.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White; $dgv.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(40, 40, 40); $dgv.AlternatingRowsDefaultCellStyle.ForeColor = [System.Drawing.Color]::LightGray; $dgv.AlternatingRowsDefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(70, 70, 110); $dgv.AlternatingRowsDefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White; $colDriver = New-Object System.Windows.Forms.DataGridViewTextBoxColumn; $colDriver.HeaderText = "Driver"; $colDriver.Name = "Driver"; $colDriver.ReadOnly = $true; $colDriver.FillWeight = 40; $dgv.Columns.Add($colDriver) | Out-Null; $colCurrent = New-Object System.Windows.Forms.DataGridViewTextBoxColumn; $colCurrent.HeaderText = "Current (us)"; $colCurrent.Name = "Current"; $colCurrent.ReadOnly = $true; $colCurrent.DefaultCellStyle.Alignment = 'MiddleRight'; $colCurrent.FillWeight = 20; $dgv.Columns.Add($colCurrent) | Out-Null; $colPrevious = New-Object System.Windows.Forms.DataGridViewTextBoxColumn; $colPrevious.HeaderText = "Previous (us)"; $colPrevious.Name = "Previous"; $colPrevious.ReadOnly = $true; $colPrevious.DefaultCellStyle.Alignment = 'MiddleRight'; $colPrevious.FillWeight = 20; $dgv.Columns.Add($colPrevious) | Out-Null; $colChange = New-Object System.Windows.Forms.DataGridViewTextBoxColumn; $colChange.HeaderText = "Change (us)"; $colChange.Name = "Change"; $colChange.ReadOnly = $true; $colChange.DefaultCellStyle.Alignment = 'MiddleRight'; $colChange.FillWeight = 20; $dgv.Columns.Add($colChange) | Out-Null; foreach ($d in $drivers) { $oldValue = $null; if ($oldDrivers) { $oldDriver = $oldDrivers | Where-Object { $_.Module -eq $d.Module } | Select-Object -First 1; if ($oldDriver) { $oldValue = $oldDriver.Value } }; $row = $dgv.Rows.Add(); $dgv.Rows[$row].Cells[0].Value = $d.Module; $dgv.Rows[$row].Cells[1].Value = $d.Value.ToString("N0"); if ($null -ne $oldValue) { $dgv.Rows[$row].Cells[2].Value = $oldValue.ToString("N0"); $diff = $d.Value - $oldValue; $sign = if ($diff -gt 0) { "+" } else { "" }; $dgv.Rows[$row].Cells[3].Value = "$($sign)$($diff.ToString('N0'))"; if ($diff -lt 0) { $dgv.Rows[$row].Cells[3].Style.ForeColor = [System.Drawing.Color]::LightGreen } else { $dgv.Rows[$row].Cells[3].Style.ForeColor = [System.Drawing.Color]::LightCoral } } else { $dgv.Rows[$row].Cells[2].Value = "N/A"; $dgv.Rows[$row].Cells[3].Value = "N/A" } }; return $dgv }
$isrOldDrivers = if ($oldResult -and $oldResult.isrDrivers) { $oldResult.isrDrivers } else { $null }; $dgvISR = Create-DataGridView $isrDrivers $isrOldDrivers;
$dpcOldDrivers = if ($oldResult -and $oldResult.dpcDrivers) { $oldResult.dpcDrivers } else { $null }; $dgvDPC = Create-DataGridView $dpcDrivers $dpcOldDrivers;

# --- NEU: TabControl durch Buttons und Panel ersetzt ---
$tabPanel = New-Object System.Windows.Forms.Panel; $tabPanel.Dock = 'Fill'; $tabPanel.BackColor = $darkColor
$btnISR = New-Object System.Windows.Forms.Button; $btnISR.Text = "ISR Drivers"; $btnISR.Location = New-Object System.Drawing.Point(5, 5); $btnISR.Size = New-Object System.Drawing.Size(120, 30); $btnISR.FlatStyle = 'Flat'; $btnISR.FlatAppearance.BorderSize = 1; $btnISR.FlatAppearance.BorderColor = $lightDarkColor; $btnISR.BackColor = $lightDarkColor;
$btnDPC = New-Object System.Windows.Forms.Button; $btnDPC.Text = "DPC Drivers"; $btnDPC.Location = New-Object System.Drawing.Point(130, 5); $btnDPC.Size = New-Object System.Drawing.Size(120, 30); $btnDPC.FlatStyle = 'Flat'; $btnDPC.FlatAppearance.BorderSize = 1; $btnDPC.FlatAppearance.BorderColor = $lightDarkColor; $btnDPC.BackColor = $darkColor;
$tabPanel.Controls.Add($btnISR); $tabPanel.Controls.Add($btnDPC)
$dgvPanel = New-Object System.Windows.Forms.Panel; $dgvPanel.Location = New-Object System.Drawing.Point(5, 40); $dgvPanel.Size = New-Object System.Drawing.Size($form.ClientSize.Width - 30, $form.ClientSize.Height - 300); $dgvPanel.Anchor = ('Top', 'Left', 'Bottom', 'Right'); $dgvPanel.BackColor = $darkColor
$dgvPanel.Controls.Add($dgvISR); $dgvPanel.Controls.Add($dgvDPC); $tabPanel.Controls.Add($dgvPanel)
$btnISR.Add_Click({ $dgvISR.BringToFront(); $btnISR.BackColor = $lightDarkColor; $btnDPC.BackColor = $darkColor }); $btnDPC.Add_Click({ $dgvDPC.BringToFront(); $btnDPC.BackColor = $lightDarkColor; $btnISR.BackColor = $darkColor });

# Hauptlayout
$mainSplitter = New-Object System.Windows.Forms.SplitContainer; $mainSplitter.Orientation = "Horizontal"; $mainSplitter.Dock = "Fill"; $mainSplitter.SplitterWidth = 8; $mainSplitter.BackColor = $lightDarkColor; $mainSplitter.SplitterDistance = 200; $mainSplitter.Panel1MinSize = 180; $mainSplitter.Panel2MinSize = 100
$topPanel = New-Object System.Windows.Forms.Panel; $topPanel.Dock = "Fill"; $topPanel.AutoScroll = $true; $topPanel.BackColor = $darkColor; $topPanel.Controls.Add($tlp); $mainSplitter.Panel1.Controls.Add($topPanel)
$mainSplitter.Panel2.Controls.Add($tabPanel) # Hier wird das neue Panel hinzugefügt

# Untere Elemente (Status & Report)
$statusText = Get-OverallStatus; $statusLines = ($statusText -split "`r`n").Count; $statusBox = New-Object System.Windows.Forms.TextBox; $statusBox.Multiline = $true; $statusBox.ReadOnly = $true; $statusBox.ScrollBars = 'None'; $statusBox.Dock = 'Bottom'; $statusBox.Height = [Math]::Min([Math]::Max($statusLines * 25, 80), 160); $statusBox.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold); $statusBox.Text = $statusText
if ($statusText -match "Critical") { $statusBox.BackColor = [System.Drawing.Color]::FromArgb(70, 0, 0); $statusBox.ForeColor = [System.Drawing.Color]::LightCoral } elseif ($statusText -match "Warning") { $statusBox.BackColor = [System.Drawing.Color]::FromArgb(70, 70, 0); $statusBox.ForeColor = [System.Drawing.Color]::LightYellow } else { $statusBox.BackColor = [System.Drawing.Color]::FromArgb(0, 50, 0); $statusBox.ForeColor = [System.Drawing.Color]::LightGreen }
$reportBox = New-Object System.Windows.Forms.TextBox; $reportBox.Multiline = $true; $reportBox.ReadOnly = $true; $reportBox.ScrollBars = 'Both'; $reportBox.Dock = 'Bottom'; $reportBox.Height = 240; $reportBox.Font = New-Object System.Drawing.Font("Consolas", 10); $reportBox.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30); $reportBox.ForeColor = [System.Drawing.Color]::LightGray; $reportBox.Text = $result.fullReport

# Formular-Steuerelemente zusammenbauen
$form.Controls.Add($mainSplitter); $form.Controls.Add($impactPanel); $form.Controls.Add($statusBox); $form.Controls.Add($reportBox)

# Formular-Events
$form.Add_FormClosed({ $saveData = [PSCustomObject]@{ isr_total = $isr_total; dpc_total = $dpc_total; maxISRPerCpu = $maxISRPerCpu; maxDPCPerCpu = $maxDPCPerCpu; isrDrivers = $isrDrivers; dpcDrivers = $dpcDrivers }; $saveData | ConvertTo-Json -Depth 5 | Out-File $lastResultFile -Encoding UTF8 })
$form.Add_FormClosing({ param($sender, $e); $result = [System.Windows.Forms.MessageBox]::Show("Do you really want to close the analysis?", "Confirmation", "YesNo", "Question"); if ($result -eq "No") { $e.Cancel = $true } })
$form.Add_Shown({ 
    $osBuild = [int](Get-CimInstance Win32_OperatingSystem).BuildNumber
    if ($osBuild -ge 22000) { try { $value = 1; [DwmApi]::DwmSetWindowAttribute($form.Handle, [DwmApi]::DWMWA_USE_IMMERSIVE_DARK_MODE, [ref]$value, 4) | Out-Null } catch { Write-Warning "Could not set dark mode for title bar: $_.Exception.Message" } }
    $form.Activate() 
})
[void]$form.ShowDialog()